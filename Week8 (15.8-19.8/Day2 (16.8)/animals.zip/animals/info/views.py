from django.shortcuts import render
import models 


def get_Family(request):
    # dictionary for initial data with 
    # field names as keys
    context ={}

def get_Animal(request):
    # dictionary for initial data with 
    # field names as keys
    context ={}

def get_Animals_all(request):
    # dictionary for initial data with 
    # field names as keys
    context ={}
