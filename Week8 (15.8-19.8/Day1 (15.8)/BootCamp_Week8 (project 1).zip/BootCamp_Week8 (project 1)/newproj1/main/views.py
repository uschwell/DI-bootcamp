
from django.shortcuts import render,HttpResponse

# Create your views here.
def homepage(request):
    return HttpResponse('hello world')




def about(request):
    return HttpResponse('This should be the "about" page')